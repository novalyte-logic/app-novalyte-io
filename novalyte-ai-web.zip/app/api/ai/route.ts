import { NextResponse } from 'next/server';
import { GoogleGenerativeAI } from '@google/generative-ai';

export async function POST(req: Request) {
  const body = await req.json();
  const genAI = new GoogleGenerativeAI(process.env.GOOGLE_API_KEY || "");
  const model = genAI.getGenerativeModel({ model: "gemini-pro" });

  const result = await model.generateContent(body.prompt);
  return NextResponse.json({ output: result.response.text() });
}
